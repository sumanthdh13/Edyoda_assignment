import React from "react";


import Form from "./Form";
import Features from "./Features";
function Main() {
    return ( 
        <div className = "main">
        <div className="main-col-1">
        <div className="main-title">
            <h1 className="raleway-title">Access curated courses worth</h1>
            <h1 className="roboto-title"><span className="line-through">₹ 18,500</span> at just <span className="highlighted-text">₹ 99</span> per year!</h1>
        </div>
        <Features/>
        </div>
        <div className="main-col-2">
        <Form/>


        </div>
        </div>

    )
}

export default Main;