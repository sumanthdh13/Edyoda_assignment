import React from "react";
import live from "../assets/live.svg";
import ads from "../assets/ads.svg";
import book from "../assets/book.svg";
import clock from "../assets/clock.svg";
import edu from "../assets/edu.svg";

export default function Features(){
    return <>
        <div className="feature-list">
            <div className="individual-list">
            <div className="list-item">
                <img src={book} alt="" className="list-img" />
                <h3 className="list-description"><span className="highlighted-text">100+</span> Job relevant courses</h3>
            </div>
            <div className="list-item">
                <img src={clock} alt="" className="list-img" />
                <h3 className="list-description"><span className="highlighted-text">20,000+</span> Hours of content</h3> 
            </div>
            <div className="list-item">
                <img src={live} alt="" className="list-img" />
                <h3 className="list-description"><span className="highlighted-text">Exclusive</span> webinar access</h3>
            </div>
            <div className="list-item">
                <img src={edu} alt="" className="list-img" />
                <h3 className="list-description">Scholarship worth <span className="highlighted-text">₹94,500</span> </h3>
            </div>
            <div className="list-item">
                <img src={ads} alt="" className="list-img" />
                <h3 className="list-description"><span className="highlighted-text">Ad Free</span> learning experience</h3>
            </div>

            </div>
        </div>
    </>
}