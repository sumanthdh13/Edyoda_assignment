import React from "react";
import logo from "../assets/EDYODA.svg";


function Header() {
    return(
        <div className="header">
            <div className="header-col-1">
                <img src={logo} alt="logo" className="logo" />
                <ul className="nav-links">
                    <li className="nav-link">Courses&nbsp; <i class="fa-solid fa-angle-down"></i></li>
                    <li className="nav-link">Programs&nbsp; <i class="fa-solid fa-angle-down"></i></li>
                </ul>
            </div>
            <div className="header-col-2">
                <div className="search-icon"><i class="fa-solid fa-magnifying-glass"></i></div>
                <h4 className="login">Log In</h4>
                <div className="join-btn"><button className="join">Join Now</button></div>
            </div>
        </div>
    )
}

export default Header;