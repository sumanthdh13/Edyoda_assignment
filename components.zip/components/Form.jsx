import React from "react";
import clock2 from "../assets/clockdanger.svg";
import razorpay from "../assets/razorpay.png";
function Form() {
    return (
        <>
            <form action="" className="subscription-form">
            <div className="plans">
                <div className="plan">
                    <h2>1</h2>
                    <h3>Sign Up</h3>
                </div>
                <div className="plan">
                    <h2>2</h2>
                    <h3>Subscribe</h3>
                </div>
            </div>
            <div className="selection-title">
                <h2>Select your subscription plan</h2>
            </div>
            <div className="pricing">
                <div className="individual-pricing disabled">
                    <div className="selection-disabled">
                        <div className="circle">
                            <div className="inner-circle"></div>
                        </div>
                        <h2>12 Months Subscription</h2>
                    </div>
                    <div className="total-price">
                        <div className="total"><span>Total</span> <h3>₹99</h3></div>
                        <div className="monthly"><h4>₹8 /mo</h4></div>
                    </div>
                </div>
            </div>
            <div className="pricing">
                <div className="individual-pricing success">
                    <div className="selection-disabled success-selection">
                        <div className="circle-success">
                            <div className="inner-circle-success"></div>
                        </div>
                        <h2>12 Months Subscription</h2>
                    </div>
                    <div className="total-price ">
                        <div className="total" style={{color:"black"}}><span>Total</span> <h3>₹179</h3></div>
                        <div className="monthly" ><h4 style={{color:"black"}}>₹15 /mo</h4></div>
                    </div>
                </div>
            </div>
            <div className="pricing">
                <div className="individual-pricing ">
                    <div className="selection-disabled selection-available">
                        <div className="circle">
                            
                        </div>
                        <h2>6 Months Subscription</h2>
                    </div>
                    <div className="total-price">
                        <div className="total" style={{color:"black"}}><span>Total</span> <h3>₹149</h3></div>
                        <div className="monthly"><h4 style={{color:"black"}}>₹25 /mo</h4></div>
                    </div>
                </div>
            </div>
            <div className="pricing">
                <div className="individual-pricing ">
                    <div className="selection-disabled selection-available">
                        <div className="circle">
                            
                        </div>
                        <h2>3 Months Subscription</h2>
                    </div>
                    <div className="total-price">
                        <div className="total" style={{color:"black"}}><span>Total</span> <h3>₹99</h3></div>
                        <div className="monthly"><h4 style={{color:"black"}}>₹33 /mo</h4></div>
                    </div>
                </div>
            </div>
            <hr />
            <div className="subscription-fee">
                <h3>Subscription Fee</h3>
                <h3>₹ 18,500</h3>
            </div>
            <div className="pricing">
            
                <div className="individual-pricing danger">
                <div className="limited-offer">
                    <h1>Limited time offer</h1>
                    <h2>- ₹ 18,401</h2>
                </div>
                    <div className="selection-disabled selection-available">
                        <img src={clock2} alt="" className="c2" />
                        <h2 style={{fontWeight:"400",color:"#de4313"}}>Offer valid till 25th March 2023</h2>
                    </div>
                    
                </div>
            </div>
            <div className="subscription-fee">
                <h3 style={{fontSize:"16px"}} ><span style={{fontWeight:"600",fontSize:"16px"}} >Total</span> (Incl. of 18% GST)</h3>
                <h3 style={{fontWeight:"600",fontSize:"24px"}}>₹ 149</h3>
            </div>
            <div className="buttons">
                <button className="cancel">Cancel</button>
                <button className="proceed">Proceed to pay</button>
            </div>
            <div className="razorpay">
                <img src={razorpay} alt="" className="razpay" />
            </div>
        </form>
        </>
    )
}

export default Form;